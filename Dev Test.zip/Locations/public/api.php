<?php

use Locations\Api;

session_cache_limiter(false);
session_start();

require_once '../vendor/autoload.php';

$app = new Api();

$app->run();
