<?php

use Locations\App;

session_cache_limiter(false);
session_start();

require_once '../vendor/autoload.php';

$app = new App();

try {
    $app->run();
} catch (Throwable $e) {
    var_dump($e->getMessage());die;
}
