const mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.webpackConfig({
    module: {
        rules: [
          {
            parser: {
              amd: false
            }
          }
        ]
      }

});

mix.js('src/App/resources/js/app.js', 'public/dist/js')
   .copy('node_modules/bootstrap/dist/fonts', 'public/dist/fonts/vendor/bootstrap')
   .copy('node_modules/font-awesome/fonts', 'public/dist/fonts/vendor/font-awesome')
   .copy('node_modules/ionicons/dist/fonts','public/dist/fonts/vendor/ionicons')
   .copy('node_modules/admin-lte/dist/img','public/dist/img')
   .copy('node_modules/admin-lte/plugins','public/dist/plugins');
