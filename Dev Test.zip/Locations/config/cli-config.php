<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\Tools\Console\ConsoleRunner;
use Locations\Api;

include_once realpath(__DIR__ . '/../vendor/autoload.php');

$app = new Api();

$em = $app->getContainer()->get(EntityManagerInterface::class);
return ConsoleRunner::createHelperSet($em);
