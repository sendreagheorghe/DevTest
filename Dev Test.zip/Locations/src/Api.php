<?php


namespace Locations;

use DI\Bridge\Slim\App;
use DI\ContainerBuilder;
use Locations\Api\ApiRoutes;

class Api extends App
{
    public function __construct()
    {
        parent::__construct();
        $this->getContainer()->get(ApiRoutes::class)->loadRoutes($this);
    }

    protected function configureContainer(ContainerBuilder $builder): void
    {
        $builder->addDefinitions(__DIR__ . '/config/container-definitions.php');
        $builder->addDefinitions(__DIR__ . '/Api/config/container-definitions.php');
    }
}
