<?php

namespace Locations\Api\Controller;

use Locations\ControllerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Http\Response;

abstract class Controller implements ControllerInterface
{
    /** @var ServerRequestInterface */
    protected $request;
    /** @var Response */
    protected $response;


    /**
     * @param ServerRequestInterface $request
     */
    public function setRequest(ServerRequestInterface $request): void
    {
        $this->request = $request;
    }

    /**
     * @param ResponseInterface $response
     */
    public function setResponse(ResponseInterface $response): void
    {
        $this->response = $response;
    }

}
