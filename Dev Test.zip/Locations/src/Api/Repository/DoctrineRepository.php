<?php

namespace Locations\Api\Repository;

use Doctrine\ORM\EntityManagerInterface;

abstract class DoctrineRepository
{
    /** @var EntityManagerInterface */
    protected $entityManager;


    protected $transactionStarted = false;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    protected function flush()
    {
        if (!$this->isTransactionStarted()) {
            $this->entityManager->flush();
        }
    }

    /**
     * @return bool
     */
    protected function isTransactionStarted(): bool
    {
        return $this->transactionStarted;
    }

    public function runTransaction(): void
    {
        $this->transactionStarted = false;
        $this->entityManager->flush();
    }

    public function beginTransaction(): void
    {
        $this->transactionStarted = true;
    }
}
