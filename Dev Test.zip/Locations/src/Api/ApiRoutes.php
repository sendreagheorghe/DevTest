<?php

namespace Locations\Api;

use Locations\Api\Locations\LocationsController;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\App;

class ApiRoutes
{
    /** @var App */
    private $app;

    public function loadRoutes(App $app): void
    {
        $this->app = $app;

        $this->setUpCors();

        $this->loadApiRoutes($app);
    }

    private function loadApiRoutes(App $app): void
    {
	    /**
	     * Routes for version 1 of the API
	     */
	    $this->app->group('/api/v1', function () use ($app){
            $app->get('/locations', [LocationsController::class, 'getLocationsBy']);
	    });
    }

    /**
     * @see http://www.slimframework.com/docs/v3/cookbook/enable-cors.html
     */
    private function setUpCors(): void
    {
	    $this->app->options('/{routes:.+}', function ($request, $response, $args) {
		    return $response;
	    });

        $this->app->add(function (ServerRequestInterface $req, ResponseInterface $res, callable $next) {
            /** @var ResponseInterface $response */
            $response = $next($req, $res);
            return $response
                ->withHeader('Access-Control-Allow-Origin', '*')
                ->withHeader(
                    'Access-Control-Allow-Headers',
                    'X-Requested-With, Content-Type, Accept, Origin, Authorization'
                )
                ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
                ->withHeader('Cache-Control', 'no-cache')
                ->withHeader('Pragma', 'no-cache')
                ->withHeader('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');
        });
    }
}
