<?php

use DoctrineExtensions\Query\Mysql\MatchAgainst;
use function DI\autowire;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Container\ContainerInterface;
use Locations\Api\ApiRoutes;

return [
	'apiPath' => dirname(__DIR__),
	EntityManagerInterface::class => function (ContainerInterface $container) {
		$connectionParams = ['url' => getenv('DSN_URL')];
		$entityDirs       = array($container->get('apiPath') . '/Repository/Entity');

		$config = \Doctrine\ORM\Tools\Setup::createAnnotationMetadataConfiguration(
			$entityDirs,
			true,
            $container->get('apiPath') . '/Repository/GeneratedProxies',
			null,
			false
		);

		if (getenv('DOCTRINE_APCU_CACHE_ENABLED') === 'true') {
			$cache = new \Doctrine\Common\Cache\ApcuCache();
            $config->setAutoGenerateProxyClasses(false);
		} else {
			$cache = new \Doctrine\Common\Cache\ArrayCache;
            $config->setAutoGenerateProxyClasses(true);
		}

		$cacheNamespace = getenv('DOCTRINE_CACHE_NAMESPACE');
		if (!$cacheNamespace) {
		    $cacheNamespace = 'Locations';
        }
		$cache->setNamespace($cacheNamespace);

        $config->addCustomDatetimeFunction('date', 'DoctrineExtensions\\Query\\Mysql\\Date');

		$config->setMetadataCacheImpl($cache);
		$config->setQueryCacheImpl($cache);

		$annotationReader       = new Doctrine\Common\Annotations\AnnotationReader();
		$cachedAnnotationReader = new Doctrine\Common\Annotations\CachedReader(
			$annotationReader,
			$cache
		);

		$driverChain = new Doctrine\Common\Persistence\Mapping\Driver\MappingDriverChain();
		Gedmo\DoctrineExtensions::registerAbstractMappingIntoDriverChainORM(
			$driverChain,
			$cachedAnnotationReader
		);

		$annotationDriver = new Doctrine\ORM\Mapping\Driver\AnnotationDriver(
			$cachedAnnotationReader,
			$entityDirs
		);
		$driverChain->addDriver($annotationDriver, 'Locations\\Api\\Repository\\Entity');

		$config->setMetadataDriverImpl($driverChain);

		$config->addCustomStringFunction('MATCH', MatchAgainst::class);

		$eventManager = new Doctrine\Common\EventManager();


		return \Doctrine\ORM\EntityManager::create($connectionParams, $config, $eventManager);
	},
    ApiRoutes::class => DI\autowire(ApiRoutes::class),
];
