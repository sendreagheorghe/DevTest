<?php


namespace Locations\Api\Locations;


class LocationsService
{
    /**
     * @var LocationsRepository $locationsRepository
     */
    private $locationsRepository;

    public function __construct(LocationsRepository $locationsRepository)
    {
        $this->locationsRepository = $locationsRepository;
    }

    public function getLocationsBy(array $queryParams = [])
    {
        return $this->locationsRepository->getLocationsBy($queryParams);
    }

}
