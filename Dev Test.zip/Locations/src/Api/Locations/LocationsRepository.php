<?php


namespace Locations\Api\Locations;


use Locations\Api\Repository\DoctrineRepository;
use Locations\Api\Repository\Entity\Locations;

class LocationsRepository extends DoctrineRepository
{
    public function getLocationsBy(array $queryParams): array
    {
        $queryBuilder = $this->entityManager->createQueryBuilder()
            ->select('locations')
            ->from(Locations::class, 'locations');

        if (!empty($queryParams['code'])) {
            $queryBuilder->andWhere(
                $queryBuilder->expr()->like('locations.code', ':code')
            );
            $queryBuilder->setParameter('code', $queryParams['code']);
        }

        $locationEntities = $queryBuilder->getQuery()->getResult();

        $locations = [];
        /** @var Locations $locationEntity */
        foreach ($locationEntities as $locationEntity) {
            $locations[] = [
                "name" => $locationEntity->getName(),
                'code' => $locationEntity->getCode(),
                'prefix' => $locationEntity->getPrefix()
            ];
        }

        return $locations;
    }
}
