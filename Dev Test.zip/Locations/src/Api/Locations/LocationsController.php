<?php


namespace Locations\Api\Locations;


use JsonRPC\Server;
use Locations\Api\Controller\Controller;

class LocationsController extends Controller
{
    /**
     * @var LocationsService $locationsService
     */
    private $locationsService;

    public function __construct(LocationsService $locationsService)
    {
        $this->locationsService = $locationsService;
    }

    public function getLocationsBy()
    {
        $queryParams = $this->request->getQueryParams();
        $locations = $this->locationsService->getLocationsBy($queryParams);

        return $this->response->withJson($locations);
    }
}
