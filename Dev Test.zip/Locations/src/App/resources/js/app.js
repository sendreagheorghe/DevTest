/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

getLocations = (code) => {
    axios.get('/api/v1/locations?code=' + code).then(
        data => {
            let div = document.getElementById("locationDiv");
            div.innerHTML = "";
            data.data.map(item => {
                let name = document.createElement("span");
                name.innerText = item.name + "---" + item.code + "---" + item.prefix + "\n";
                div.appendChild(name);
            });
        }
    )
};
