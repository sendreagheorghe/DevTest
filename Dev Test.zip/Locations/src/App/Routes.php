<?php

namespace Locations\App;

use Locations\App\Controller\IndexController;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\App;
use Slim\Http\StatusCode;
use Slim\Interfaces\RouterInterface;

class Routes
{
    public function loadRoutes(App $app) : void
    {
        $router = $app->getContainer()->get(RouterInterface::class);


        $app->get('/', function (ResponseInterface $response) use ($app, $router) {

            return $response
                ->withHeader('Location', $router->pathFor('locations'))
                ->withStatus(StatusCode::HTTP_TEMPORARY_REDIRECT);
        });

        $app->group('/locations', function () use ($app) {
            $app->get('', [IndexController::class, 'view'])->setName('locations');
        })->add($this->getRouteMiddlewareMiddleware($router));
    }

    private function getRouteMiddlewareMiddleware(RouterInterface $router) : callable
    {
        return function (ServerRequestInterface $request, ResponseInterface $response, callable $next) use ($router) {
            return $next($request, $response);
        };
    }
}
