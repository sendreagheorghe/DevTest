<?php

namespace Locations\App\Controller;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Http\Response;
use Slim\Views\Twig;
use Locations\ControllerInterface;

abstract class Controller implements ControllerInterface
{
    /** @var ServerRequestInterface */
    protected $request;
    /** @var Response */
    protected $response;
    /** @var Twig */
    protected $view;

    public function __construct( Twig $twig)
    {
        $this->view = $twig;
    }

    /**
     * @param ServerRequestInterface $request
     */
    public function setRequest(ServerRequestInterface $request): void
    {
        $this->request = $request;
    }

    /**
     * @param Response $response
     */
    public function setResponse(ResponseInterface $response): void
    {
        $this->response = $response;
    }

    protected function renderPage($view, $data = [], $layout = 'layout/index.html')
    {
        return $this->render('pages/' . $view, $data, $layout);
    }


    private function render(string $view, array $data, string $layout)
    {
        $data = array_merge($data, [
            'content' => $this->view->fetch($view, $data),
        ]);

        return $this->view->render($this->response, $layout, $data);
    }
}
