<?php


namespace Locations\App\Controller;


class IndexController extends Controller
{
    public function view()
    {
        return $this->renderPage('locations.html', [
            'data' => 'string'
        ]);
    }
}
