<?php

use Psr\Container\ContainerInterface;
use Slim\Interfaces\RouterInterface;
use Slim\Router;
use Slim\Views\Twig;
use Twig\TwigFunction;

return [
    'appPath' => dirname(__DIR__),
    'apiBaseUrl' => function(ContainerInterface $container) {
        return getenv('API_BASE_URL') ?? $container->get('baseUrl');
    },
    Twig::class => function (ContainerInterface $container) {
        $view = new Twig($container->get('appPath') . '/view');

        /** @var Router $router */
        $router = $container->get(RouterInterface::class);
        $translateFunction = new TwigFunction('pathFor', function (string $routeName, array $data = [], array $queryParams = []) use ($router) {
            return $router->pathFor($routeName, $data, $queryParams);
        });
        $view->getEnvironment()->addFunction($translateFunction);

        $view->addExtension(new Slim\Views\TwigExtension(
            $container->get('router'),
            $container->get('request')->getUri()
        ));
        $view->getLoader();
        return $view;
    },
];
