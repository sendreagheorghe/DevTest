<?php

namespace Locations;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class ControllerInvoker extends \DI\Bridge\Slim\ControllerInvoker
{
    /**
     * Invoke a route callable.
     *
     * @param callable|closure       $callable       The callable to invoke using the strategy.
     * @param ServerRequestInterface $request        The request object.
     * @param ResponseInterface      $response       The response object.
     * @param array                  $routeArguments The route's placeholder arguments
     *
     * @return ResponseInterface|string The response from the callable.
     */
    public function __invoke(
        $callable,
        ServerRequestInterface $request,
        ResponseInterface $response,
        array $routeArguments
    ) {
        if (is_array($callable)) {
            /** @var ControllerInterface $controller */
            $controller = $callable[0];
            $controller->setRequest($request);
            $controller->setResponse($response);
        }

        return parent::__invoke($callable, $request, $response, $routeArguments);
    }
}
