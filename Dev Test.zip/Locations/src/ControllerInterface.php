<?php

namespace Locations;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

interface ControllerInterface
{
    /**
     * @param ServerRequestInterface $request
     */
    public function setRequest(ServerRequestInterface $request): void;

    /**
     * @param ResponseInterface $response
     */
    public function setResponse(ResponseInterface $response): void;
}
