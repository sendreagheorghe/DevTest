<?php

namespace Locations;

use DI\ContainerBuilder;
use Locations\App\Routes;

class App extends \DI\Bridge\Slim\App
{
    public function __construct()
    {
        parent::__construct();
        $this->getContainer()->get(Routes::class)->loadRoutes($this);
    }

    protected function configureContainer(ContainerBuilder $builder): void
    {
        $builder->addDefinitions(__DIR__ . '/config/container-definitions.php');
        $builder->addDefinitions(__DIR__ . '/App/config/container-definitions.php');
    }
}
