<?php

namespace Locations;

use DI\Bridge\Slim\App;
use DI\ContainerBuilder;

class Cli extends App
{
    protected function configureContainer(ContainerBuilder $builder): void
    {
        $builder->addDefinitions(__DIR__ . '/config/container-definitions.php');
        $builder->addDefinitions(__DIR__ . '/Api/config/container-definitions.php');
    }
}
