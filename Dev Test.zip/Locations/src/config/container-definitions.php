<?php

use GuzzleHttp\Client;
use GuzzleHttp\RequestOptions;
use Http\Adapter\Guzzle6\Client as GuzzleAdapter;
use Locations\ControllerInvoker;
use Nyholm\DSN;
use Psr\Container\ContainerInterface;
use Psr\Http\Client\ClientInterface;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Http\Request;
use Slim\Interfaces\RouterInterface;

return [
    RequestInterface::class => DI\get('request'),
    Request::class => DI\get('request'),
    ServerRequestInterface::class => DI\get('request'),
    RouterInterface::class => DI\get('router'),
    'settings.displayErrorDetails' => true,
    'baseUrl' => function (ContainerInterface $container) {
        /** @var Request $request */
        $request = $container->get('request');
        // Default scheme is HTTPS
        $isSecure = getenv('HTTPS');
        $scheme = (!empty($isSecure) && $isSecure === 'off') ? 'http' : 'https';
        $uri = $request->getUri()->withScheme($scheme);

        $baseUrl = '';
        if (is_callable([$uri, 'getBaseUrl'])) {
            $baseUrl = $uri->getBaseUrl();
        }

        return $baseUrl;
    },
    'foundHandler' => function (ContainerInterface $container) {
        $baseUrl = $container->get('baseUrl');

        if (!empty($baseUrl) && is_callable([$container->get('router'), 'setBasePath'])) {
            $container->get('router')->setBasePath($baseUrl);
        }

        return new ControllerInvoker($container->get('foundHandler.invoker'));
    },
    ClientInterface::class => function () {
        return new GuzzleAdapter(new Client([
            RequestOptions::HTTP_ERRORS => false
        ]));
    },
    DSN::class => DI\autowire(DSN::class),
];
