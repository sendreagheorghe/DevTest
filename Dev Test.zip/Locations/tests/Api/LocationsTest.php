<?php


namespace LocationsTest\Api;


use GuzzleHttp\Client;
use LocationsTest\Config\SetupGuzzle;
use PHPUnit\Framework\TestCase;

class LocationsTest extends TestCase
{
    public function testGetLocations()
    {
        $res = (new SetupGuzzle())->getClientInstance()
            ->request('GET', 'http://localhost:4040/api/v1/locations?code=RO');

        $location = json_decode($res->getBody())[0];

        $this->assertEquals('Romania', $location->name);
        $this->assertEquals('RO', $location->code);
        $this->assertEquals('+40', $location->prefix);
    }
}
