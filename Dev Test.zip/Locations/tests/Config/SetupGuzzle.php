<?php


namespace LocationsTest\Config;


use GuzzleHttp\Client;

class SetupGuzzle
{
    public function getClientInstance()
    {
        return new Client();
    }
}
