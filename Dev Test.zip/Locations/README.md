
## Setup

### Local machine setup

Prerequisites:

- Docker : 
    - [Ubuntu] https://docs.docker.com/install/linux/docker-ce/ubuntu/
    - [Mac] https://hub.docker.com/editions/community/docker-ce-desktop-mac
    - [Windows] https://hub.docker.com/editions/community/docker-ce-desktop-windows

Run the following commands in a terminal:
```
docker-compose up -d
```

`/var/www/vard/locations` represents your local path of the root directory of this project

`4040` is the port you will use when accessing the project (e.g. http://localhost:4040), you can change it if you want

Now you need to run `composer install` 

## Test
To run the functional tests manually on the local environment run the following commands:
```
docker-compose -f docker-compose-tests.yml up -d;
vendor/bin/phpunit tests/Api/*

```
For migrating database run the following command

`docker exec -it locations-running;`

``
    cd /var/www/html/locations/config && php ../vendor/bin/doctrine orm:schema-tool:update --force
``
